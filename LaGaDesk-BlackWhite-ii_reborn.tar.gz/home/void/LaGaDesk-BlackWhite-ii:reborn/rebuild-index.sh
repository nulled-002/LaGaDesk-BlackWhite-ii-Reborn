#!/bin/bash
# Re-run from inside the theme folder after adding/moving icons: bash rebuild-index.sh
# Run this from INSIDE the theme folder (the one containing 16x16, 22x22, scalable, ...).
# It (1) cleans a few stray files, (2) rebuilds index.theme from the folders that really exist.
set -e

NAME="LaGaDesk-BlackWhite-II"

# --- 1. cleanup -------------------------------------------------------------
# folder typo: 32x32/action -> 32x32/actions
[ -d 32x32/action ] && [ ! -d 32x32/actions ] && mv 32x32/action 32x32/actions

# files whose names end in "=" (copy/paste junk): strip the "=" if the clean
# name is free, otherwise delete the duplicate
find . -name '*=' -type f | while read -r f; do
  clean="${f%=}"
  if [ -e "$clean" ]; then rm -- "$f"; else mv -- "$f" "$clean"; fi
done

# scalable/apps/screenlets.svn is really a PNG with a wrong extension
if [ -f scalable/apps/screenlets.svn ]; then
  if [ -e scalable/apps/screenlets.png ]; then rm scalable/apps/screenlets.svn
  else mv scalable/apps/screenlets.svn scalable/apps/screenlets.png; fi
fi

# --- 2. rebuild index.theme -------------------------------------------------
python3 - "$NAME" <<'EOF'
import os, sys, struct, collections

name = sys.argv[1]
CONTEXT = {
    "actions": "Actions", "action": "Actions", "apps": "Applications",
    "categories": "Categories", "devices": "Devices", "emblems": "Emblems",
    "mimetypes": "MimeTypes", "places": "Places", "status": "Status",
    "animations": "Animations", "spinner": "Animations",
}

def png_size(path):
    try:
        with open(path, "rb") as f:
            h = f.read(24)
        if h[:8] == b"\x89PNG\r\n\x1a\n":
            w, hh = struct.unpack(">II", h[16:24])
            return min(w, hh)
    except OSError:
        pass
    return None

sections = []
for root, dirs, files in sorted(os.walk(".")):
    icons = [f for f in files if f.lower().endswith((".png", ".svg", ".xpm"))]
    if not icons or root == ".":
        continue
    d = root[2:]
    parts = d.split("/")
    leaf = parts[-1].lower()
    ctx = CONTEXT.get(leaf)
    if not ctx:
        print("skipping unknown folder:", d)
        continue

    svg = sum(f.lower().endswith(".svg") for f in icons)
    png = len(icons) - svg

    # nominal size: folder name like 48x48, otherwise the most common PNG size
    size = None
    if "x" in parts[0] and parts[0].split("x")[0].isdigit():
        size = int(parts[0].split("x")[0])
    if leaf in ("animations", "spinner"):
        size = 22
    if size is None:
        sizes = collections.Counter(
            s for s in (png_size(os.path.join(root, f)) for f in icons if f.lower().endswith(".png")) if s)
        size = sizes.most_common(1)[0][0] if sizes else 64

    if svg > png:
        sections.append((d, f"[{d}]\nSize={size}\nContext={ctx}\nType=Scalable\nMinSize=8\nMaxSize=512\n"))
    else:
        sections.append((d, f"[{d}]\nSize={size}\nContext={ctx}\nType=Fixed\n"))

with open("index.theme", "w") as out:
    out.write("[Icon Theme]\n")
    out.write(f"Name={name}\n")
    out.write("Comment=mixed by LaGaDesk (black-white_2_Neon, mac4lin, hydroxygen, blended crystal, breathless, dark glass and others)\n")
    out.write("Inherits=hicolor\n")
    out.write("Directories=" + ",".join(d for d, _ in sections) + "\n\n")
    out.write("\n".join(s for _, s in sections))
print(f"index.theme written with {len(sections)} directories")
EOF
